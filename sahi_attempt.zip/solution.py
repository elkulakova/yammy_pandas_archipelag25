import numpy as np
from typing import List, Union

from sahi import AutoDetectionModel
from ultralytics import YOLO
from sahi.predict import get_sliced_prediction

model = YOLO('best_new.pt')

detection_model = AutoDetectionModel.from_pretrained(
    model_type="yolov8",
    model=model,
    confidence_threshold=0.3,
    device="cuda"  # или "cpu"
)

def prediction(img):
    results = get_sliced_prediction(
        image=img,
        detection_model=detection_model,
        slice_height=320,          # Высота каждого тайла
        slice_width=320,           # Ширина каждого тайла
        overlap_height_ratio=0.4,  # 40% перекрытие по высоте
        overlap_width_ratio=0.4,    # 40% перекрытие по ширине
    )
    return results


def infer_image_bbox(image: np.ndarray) -> List[dict]:
    """Функция для получения ограничивающих рамок объектов на изображении.

    Args:
        image (np.ndarray): Изображение, на котором будет производиться инференс.

    Returns:
        List[dict]: Список словарей с координатами ограничивающих рамок и оценками.
        Пример выходных данных:
        [
            {
                'xc': 0.5,
                'yc': 0.5,
                'w': 0.2,
                'h': 0.3,
                'label': 0,
                'score': 0.95
            },
            ...
        ]
    """
    res_list = []
    image_height, image_width = image.shape[:2]
    result = prediction(image).object_prediction_list
    
    # Если есть результаты, обрабатываем их
    if len(result) > 0:
        for pred in result:
                if pred.category.id == 0:
                    x1, y1, x2, y2 = pred.bbox.to_xyxy()

                    # Вычисление нормализованных координат
                    xc = round((x1 + x2) / (2 * image_width), 4)
                    yc = round((y1 + y2) / (2 * image_height), 4)
                    w = round((x2 - x1) / image_width, 4)
                    h = round((y2 - y1) / image_height, 4)
                    conf = round(pred.score.value, 4)

                    formatted = {
                        'xc': xc,
                        'yc': yc,
                        'w': w,
                        'h': h,
                        'label': 0,
                        'score': conf
                    }
                    res_list.append(formatted)

    return res_list


def predict(images: Union[List[np.ndarray], np.ndarray]) -> List[List[dict]]:
    """Функция производит инференс модели на одном или нескольких изображениях.

    Args:
        images (Union[List[np.ndarray], np.ndarray]): Список изображений или одно изображение.

    Returns:
        List[List[dict]]: Список списков словарей с результатами предикта 
        на найденных изображениях.
        Пример выходных данных:
        [
            [
                {
                    'xc': 0.5,
                    'yc': 0.5,
                    'w': 0.2,
                    'h': 0.3,
                    'label': 0,
                    'score': 0.95
                },
                ...
            ],
            ...
        ]
    """    
    results = []
    if isinstance(images, np.ndarray):
        images = [images]

    # Обрабатываем каждое изображение из полученного списка
    for image in images:        
        image_results = infer_image_bbox(image)
        results.append(image_results)
    
    return results
