class HuggingfaceTestConstants:
    YOLOS_TINY_MODEL_PATH = "hustvl/yolos-tiny"
    RTDETRV2_MODEL_PATH = "PekingU/rtdetr_v2_r18vd"
